// vowel_rec.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <math.h> 
#include <string>

int P = 12;
int Q = 0;
long frame_size = 320;
long double pi = 3.141593;
std::ifstream infile;

using namespace std;

// DC Shift Function
void DC_Shift(vector<long double>&samples){

	long double sum = 0.0;
	if(samples.size()==0){		//base case
		return;
	}
	for(unsigned int i = 0;i<samples.size();i++){
		sum+=samples[i];		// sum over all iterations
	}
	long double avg = sum/(long double)samples.size();

	for(unsigned int i = 0;i<samples.size();i++){
		samples[i] = samples[i] - avg;		// DC Shift Step
	}

	return;	
}

//Normalization
void normalize(vector<long double>&samples){
	
	long double max_value = 0;
	for(unsigned int i=0;i<samples.size();i++){
		if(samples[i]>max_value){
			max_value = samples[i];	//finding max value
		}

		if(-1*samples[i] >max_value){
			max_value = samples[i]*-1;		//since there are negative values as well
		}
	}
	if(max_value == 0){
		return;
	}

	for(unsigned int i=0;i<samples.size();i++){
		samples[i] = samples[i]*10000.0/max_value;		// normalization step
	}

	return;
}

//Durbin Algo
vector<long double> durbin(vector<long double> R){
	vector<long double> E(13, 0.0), K(13, 0.0), alpha(13, 0.0), old_alpha(13, 0.0);		// vectors to store values
	long double sum;
	if(R[0] == 0.0){
		return alpha;		// if first R value is 0
	}
	E[0] = R[0];	//initialise
	for(int i=1; i<=P; i++){
		sum = 0.0;
		for(int j=1; j<=i-1;j++){
			sum = sum + old_alpha[j]*R[i-j];		// iterate over all i's
		}
		K[i] = (R[i] - sum)/E[i-1];
		alpha[i] = K[i];
		for(int j = 1; j<=i-1; j++){
			alpha[j] = old_alpha[j] - (K[i]*old_alpha[i-j]);	// given formula to calculate new alpha values from old values
		}
		E[i] = (1-K[i]*K[i])*E[i-1];		// store the values of E[i]
		for(int j=0; j<=P; j++){
			old_alpha[j] = alpha[j];		// update old alpha for next iteration
		}
	}
	alpha.erase(alpha.begin());		// first value is not required
	return alpha;
}

// Raised Sine Window function
void raised_sine_window(vector<long double>&C){
	Q=P;
	for(unsigned int i=0;i<C.size();i++){
		C[i] = 1+(Q/2)*sin(pi*C[i]/2.0);			// Formula
	
	}
	return;
}

//calculating cepstral co-efficients
vector<long double> cal_C(vector<long double> alpha){
	Q = P;		// given
	vector<long double>C(Q,0);	//to store

	for(int i = 0;i<P;i++){
		alpha[i] = alpha[i]*(1);		//old alpha 
	}


	for(int m=1; m<=P; m++){
		long double sum = 0;

		for(int k=1; k<m; k++){
			sum = sum + ((long double)k/(long double)m)*C[k-1]*alpha[m-k-1];		// formula for single element to calculate C's from old alpha's
		}
		C[m-1] = alpha[m-1] + sum;	//updating C values
	}


	for(int m=P+1; m<=Q; m++){
		long double sum = 0;
		for(int k=m-P; k<m; k++){
			sum = sum + (k/m)*C[k]*alpha[m-k-1];	// formula for calculation
		}

		C[m-1] = sum;		// updating the final value for C
	}
	return C;
}

//To Find tokhura distance
long double tokhura_distance(vector<long double>A, vector<long double> B){
	long double tokhura_coeffs[] = { 1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};		//Given values
	long double distance = 0.0;		//initialisation

	if(A.size()!=B.size()){
		return 0;
	}

	for(unsigned int i=0;i<A.size()&&i<B.size();i++){
		distance+=tokhura_coeffs[i]*(A[i]-B[i])*(A[i]-B[i]);			// formula for tokhura distance
	}
	return distance;
}

//find the STE
long double STE(vector<long double>frame){
	long double sum = 0.0;

	for(unsigned int i=0;i<frame.size();i++){
		sum+=frame[i];		//sum over all the iterated samples
	}

	return sum/(long double)frame.size();		//average

}


//Function to get the frame samples
vector<long double>get_frame_samples(vector<long double>samples, int frame){
	vector<long double> frame_samples;
	for(int i = (frame-1)*frame_size; i<(frame)*frame_size;i++){
		frame_samples.push_back(samples[i]);
	}
	return frame_samples;
}

//To calculate R values
vector<long double> findR(vector<long double> frame){
		vector<long double>R(P+1,0.0);

		for(int j=0;j<=P;j++){			// for all P i.e 12
			long double square_temp = 0;
			for(int t=0;t<320-j;t++){
				square_temp+=frame[t]*frame[t+j];	// since R is sigma of value(i) * value(t+i) for all the frames till t+i < frame_size;
			}
			R[j] = square_temp/320.0;	// average 
		}

		return R;
}

//To find the highest STE Frame
int maxSTEFrame(vector<long double> samples){
	vector<long double>frame;
	long double highest_ste = 0.0;
	long highest_ste_frame = 5;
	long double temp;
	// Iterating through all the frames
	for(unsigned int i=0;i<samples.size();i++){
		frame.push_back(samples[i]);
		if((i+1)%320==0){
			temp = STE(frame);
			if(temp>highest_ste){
				highest_ste = temp;
				highest_ste_frame = (i+1)/320;
			}
			frame.clear();
		}
	
	}
	return highest_ste_frame;
}

// Training Function
void rec_train(){
	Q = P;		// For our experiment, we take Q=P

	// For storing all the frame samples, cepstral coefficients and R values
	vector<long double>frame_samples;
	vector<long double> R;
	vector<long double> alpha;
	vector<long double> C;
	string vowel_files[5][10] = {{"a1.txt", "a2.txt", "a3.txt", "a4.txt", "a5.txt", "a6.txt", "a7.txt", "a8.txt", "a9.txt", "a10.txt"}, {"e1.txt", "e2.txt", "e3.txt", "e4.txt", "e5.txt", "e6.txt", "e7.txt", "e8.txt", "e9.txt", "e10.txt"}, {"i1.txt", "i2.txt", "i3.txt", "i4.txt", "i5.txt", "i6.txt", "i7.txt", "i8.txt", "i9.txt", "i10.txt"}, {"o1.txt", "o2.txt", "o3.txt", "o4.txt", "o5.txt", "o6.txt", "o7.txt", "o8.txt", "o9.txt", "o10.txt"}, {"u1.txt", "u2.txt", "u3.txt", "u4.txt", "u5.txt", "u6.txt", "u7.txt", "u8.txt", "u9.txt", "u10.txt"}};
	
	ofstream outfile("cep_coeffs.txt");	// to store the Ci values after computing
	vector<long double> samples;
	int count;
	string line;
	for(unsigned int i=0;i<5;i++){
		count = 1;
		
		vector<vector<long double>> temp(5,vector<long double>(12,0.0));
		while(count<=10){
			samples.clear();
			std::ifstream infile("train/"+vowel_files[i][count-1]);
			cout<<vowel_files[i][count-1]<<"\n";
			while (getline (infile, line)) {
				samples.push_back(stold(line));
			}
			// DC Shift and Normalize the samples
			DC_Shift(samples);
			normalize(samples);
			int f = maxSTEFrame(samples);	// get highest STE Frame
			for(int frame = f-2;frame<=f+2;frame++){
				frame_samples = get_frame_samples(samples, frame);
				R = findR(frame_samples);	//calculate R values
				alpha = durbin(R);		//Durbin algo
				C = cal_C(alpha);		// find cepstral coefficients after durbin
	
				//storing all ci's for each of the variable
				for(int k = 0;k<Q;k++){
					temp[frame-f+2][k]+=C[k];
					if(count == 10){
						temp[frame-f+2][k] = temp[frame-f+2][k]/10.0;
						cout<<temp[frame-f+2][k]<<" ";
						outfile<<temp[frame-f+2][k]<<" ";
					}
				}
				if(count == 10){
						cout<<"\n";
						outfile<<"\n";
				}
			}
			count++;
		}
		cout<<"\n\n";
		outfile<<"\n\n";
	
	}

}

// Tokenize Function
vector<long double>tokenize(string line){
	vector<long double> C;
	string token = "";
	
	//storing the value in a vector of long double for calculations
	for(int i=0;i<line.length();i++){
		
		if(line[i] == ' ' && token!=""){
			C.push_back(stold(token));
			token = "";
		}
		
		else if(line[i]!=' ' ){
			token = token+line[i];
		}
	}

	if(token!=""){
		C.push_back(stold(token));
	}

	return C;
}

// Function for testing
int test(string test_file){

	// For storing cepstral co-efficients, samples, R & alpha values, 
	string line;
	vector<vector<long double>> c_coeffs(25,vector<long double>(12,0.0)); 
	vector<long double>samples;
	vector<long double>frame_samples;
	vector<long double> R;
	vector<long double> alpha;
	vector<long double> C;

	std::ifstream infile("cep_coeffs.txt");
	for(unsigned int i = 0;i<5;i++){
		for(unsigned int j = 0;j<5;j++){
			getline (infile, line);
			c_coeffs[i*5+j] = tokenize(line);  // tokenize values
		}
		getline (infile, line);getline (infile, line);
	}

	infile.close();
	vector<vector<long double>> temp(5,vector<long double>(12,0.0));		// 12 length file for storage
	std::ifstream infile_test(test_file);		// open the test file

	while (getline (infile_test, line)) {
		samples.push_back(stold(line));
	}

	// DC Shift and normalize the values
	DC_Shift(samples);
	normalize(samples);

	int f = maxSTEFrame(samples);	// highest STE Frame
	// Get Frame sample, calculate R and C 
	for(unsigned int frame = f-2;frame<=f+2;frame++){
		frame_samples = get_frame_samples(samples, frame);	
		R = findR(frame_samples);
		alpha = durbin(R);
		C = cal_C(alpha);
		for(unsigned int k = 0;k<Q;k++){
			temp[frame-f+2][k] = C[k];
		}			
	}

	vector<long double>tokhura_distances(5,0.0); // 1 for each vowel

	//finding tokhura distance with respect to each vowel's trained data
	for(unsigned int i =0;i<5;i++){
		for(unsigned int j=0;j<5;j++){
			tokhura_distances[i] = tokhura_distances[i] + tokhura_distance(temp[j], c_coeffs[i*5+j]);
		}
	}

	long double min_distance = tokhura_distances[0];
	long min_distance_index = 0;

	// minimum tokhura distance vowel is our predicted variable
	for(int i=0;i<5;i++){
		if(tokhura_distances[i]<min_distance){
			min_distance = tokhura_distances[i];
			min_distance_index = i;
		}
	}
	return (int)min_distance_index+1;		// array indexing using base 1

}


// Driver Function
int _tmain(int argc, _TCHAR* argv[])
{
	cout<<"Starting Training"<<endl;
	rec_train();
	string vowel_files[5][10] = {{"a1.txt", "a2.txt", "a3.txt", "a4.txt", "a5.txt", "a6.txt", "a7.txt", "a8.txt", "a9.txt", "a10.txt"}, {"e1.txt", "e2.txt", "e3.txt", "e4.txt", "e5.txt", "e6.txt", "e7.txt", "e8.txt", "e9.txt", "e10.txt"}, {"i1.txt", "i2.txt", "i3.txt", "i4.txt", "i5.txt", "i6.txt", "i7.txt", "i8.txt", "i9.txt", "i10.txt"}, {"o1.txt", "o2.txt", "o3.txt", "o4.txt", "o5.txt", "o6.txt", "o7.txt", "o8.txt", "o9.txt", "o10.txt"}, {"u1.txt", "u2.txt", "u3.txt", "u4.txt", "u5.txt", "u6.txt", "u7.txt", "u8.txt", "u9.txt", "u10.txt"}};
	
	char vowel[5] = {'a','e','i','o','u'};		//store of vowels
	int p = 0;		// initialise P as 0

	cout<<"\nStarting Testing \n";
	for(int i=0;i<5;i++){
		for(int j=0;j<10;j++){
			char ide = vowel[test("test/"+vowel_files[i][j])-1];
			cout<<"Actual Test Vowel: "<<vowel[i]<<";		Identified Test Vowel: "<<vowel[test("test/"+vowel_files[i][j])-1]<<"\n";

			if(ide != vowel[i]){
				p++;
			}
		}
	
	}
	cout<<"\n\n\n";
	cout<<"Vowels identified incorrectly: "<<p<<"\n";		//False Tested Data
	double accuracy = (50-p)/50.0;
	cout<<"Accuracy: "<<accuracy<<"\n";	//Accuracy
	return 0;

}

